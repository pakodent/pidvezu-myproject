# pidvezu
Pidvezu is a free platform for volunteer drivers to help transport things, food for refugees or passengers, animals during the war in Ukraine. (pidvezu.com.ua) + Telegram Bot to notify about the status of applications.
This project is ready to be deployed on the server. Missing Gunicorn and Nginx configuration (if you need help in compiling, feel free to ask).

![pz](https://user-images.githubusercontent.com/68155915/191244463-bd53cc96-da6e-431d-af23-e3903017a3c8.jpg)

![3](https://user-images.githubusercontent.com/68155915/199688537-65026bd0-d371-48ef-a861-b8df8f164c9f.jpg)
