﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","zh",{title:"元件資訊",dialogName:"對話視窗名稱",tabName:"標籤名稱",elementId:"元件 ID",elementType:"元件類型"});